globalThis.__slcSlot9f3e2a7c=Object.assign(globalThis.__slcSlot9f3e2a7c||{},{"lang":"pt-BR","langs":["pt-BR","pt"]});

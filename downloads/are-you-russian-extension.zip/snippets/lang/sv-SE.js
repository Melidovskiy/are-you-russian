globalThis.__slcSlot9f3e2a7c=Object.assign(globalThis.__slcSlot9f3e2a7c||{},{"lang":"sv-SE","langs":["sv-SE","sv"]});
